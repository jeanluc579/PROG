﻿namespace POE2_PROG
{
    partial class SignInForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlSignIn1 = new System.Windows.Forms.Panel();
            this.txtSignInUsrNm = new System.Windows.Forms.TextBox();
            this.txtSignInPass = new System.Windows.Forms.TextBox();
            this.lblSignInUsrNm = new System.Windows.Forms.Label();
            this.lblSignInPass = new System.Windows.Forms.Label();
            this.btnSignInLogin = new System.Windows.Forms.Button();
            this.btnSignInRegister = new System.Windows.Forms.Button();
            this.lblLogin = new System.Windows.Forms.Label();
            this.pnlSignIn1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlSignIn1
            // 
            this.pnlSignIn1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pnlSignIn1.Controls.Add(this.lblLogin);
            this.pnlSignIn1.Location = new System.Drawing.Point(1, 1);
            this.pnlSignIn1.Name = "pnlSignIn1";
            this.pnlSignIn1.Size = new System.Drawing.Size(487, 100);
            this.pnlSignIn1.TabIndex = 0;
            // 
            // txtSignInUsrNm
            // 
            this.txtSignInUsrNm.Location = new System.Drawing.Point(188, 219);
            this.txtSignInUsrNm.Name = "txtSignInUsrNm";
            this.txtSignInUsrNm.Size = new System.Drawing.Size(174, 20);
            this.txtSignInUsrNm.TabIndex = 1;
            // 
            // txtSignInPass
            // 
            this.txtSignInPass.Location = new System.Drawing.Point(188, 266);
            this.txtSignInPass.Name = "txtSignInPass";
            this.txtSignInPass.Size = new System.Drawing.Size(174, 20);
            this.txtSignInPass.TabIndex = 2;
            this.txtSignInPass.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // lblSignInUsrNm
            // 
            this.lblSignInUsrNm.AutoSize = true;
            this.lblSignInUsrNm.Location = new System.Drawing.Point(88, 219);
            this.lblSignInUsrNm.Name = "lblSignInUsrNm";
            this.lblSignInUsrNm.Size = new System.Drawing.Size(63, 13);
            this.lblSignInUsrNm.TabIndex = 4;
            this.lblSignInUsrNm.Text = "User Name:";
            // 
            // lblSignInPass
            // 
            this.lblSignInPass.AutoSize = true;
            this.lblSignInPass.Location = new System.Drawing.Point(88, 266);
            this.lblSignInPass.Name = "lblSignInPass";
            this.lblSignInPass.Size = new System.Drawing.Size(56, 13);
            this.lblSignInPass.TabIndex = 5;
            this.lblSignInPass.Text = "Password:";
            // 
            // btnSignInLogin
            // 
            this.btnSignInLogin.Location = new System.Drawing.Point(188, 313);
            this.btnSignInLogin.Name = "btnSignInLogin";
            this.btnSignInLogin.Size = new System.Drawing.Size(75, 37);
            this.btnSignInLogin.TabIndex = 6;
            this.btnSignInLogin.Text = "Login";
            this.btnSignInLogin.UseVisualStyleBackColor = true;
            this.btnSignInLogin.Click += new System.EventHandler(this.btnSignInLogin_Click);
            // 
            // btnSignInRegister
            // 
            this.btnSignInRegister.Location = new System.Drawing.Point(287, 313);
            this.btnSignInRegister.Name = "btnSignInRegister";
            this.btnSignInRegister.Size = new System.Drawing.Size(75, 37);
            this.btnSignInRegister.TabIndex = 7;
            this.btnSignInRegister.Text = "Register";
            this.btnSignInRegister.UseVisualStyleBackColor = true;
            this.btnSignInRegister.Click += new System.EventHandler(this.btnSignInRegister_Click);
            // 
            // lblLogin
            // 
            this.lblLogin.AutoSize = true;
            this.lblLogin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.lblLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogin.Location = new System.Drawing.Point(206, 37);
            this.lblLogin.Name = "lblLogin";
            this.lblLogin.Size = new System.Drawing.Size(99, 31);
            this.lblLogin.TabIndex = 8;
            this.lblLogin.Text = "LOGIN";
            // 
            // SignInForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(489, 496);
            this.Controls.Add(this.btnSignInRegister);
            this.Controls.Add(this.btnSignInLogin);
            this.Controls.Add(this.lblSignInPass);
            this.Controls.Add(this.lblSignInUsrNm);
            this.Controls.Add(this.txtSignInPass);
            this.Controls.Add(this.txtSignInUsrNm);
            this.Controls.Add(this.pnlSignIn1);
            this.Name = "SignInForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "9";
            this.pnlSignIn1.ResumeLayout(false);
            this.pnlSignIn1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlSignIn1;
        private System.Windows.Forms.TextBox txtSignInUsrNm;
        private System.Windows.Forms.TextBox txtSignInPass;
        private System.Windows.Forms.Label lblSignInUsrNm;
        private System.Windows.Forms.Label lblSignInPass;
        private System.Windows.Forms.Button btnSignInLogin;
        private System.Windows.Forms.Button btnSignInRegister;
        private System.Windows.Forms.Label lblLogin;
    }
}