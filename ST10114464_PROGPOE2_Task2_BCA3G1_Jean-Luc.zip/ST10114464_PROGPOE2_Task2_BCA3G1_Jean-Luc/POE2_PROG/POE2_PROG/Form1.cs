﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POE2_PROG
{
    public partial class FrmReg : Form
    {
        public FrmReg()
        {
            InitializeComponent();
        }

        PROG_POEP2Entities db = new PROG_POEP2Entities();



        //--------------------------------------------------------------------------------------------------------------------------//
        private void lblUsername_Click(object sender, EventArgs e)
        {

        }
        //--------------------------------------------------------------------------------------------------------------------------//

        //--------------------------------------------------------------------------------------------------------------------------//
        public bool IsEmpty()
        {

            //if else statement to see if fields are filled with correct informaton
            if (txtPassword.Text.Trim() == "" || txtUserName.Text.Trim() == "")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        //--------------------------------------------------------------------------------------------------------------------------//

        //--------------------------------------------------------------------------------------------------------------------------//
        private void btnRegister_Click(object sender, EventArgs e)
        {
            
            tblSignup obj= new tblSignup();
            //if else statement to see if fields have been filled, if no fields are filled an error message will display
            if (!IsEmpty()) 
            {
                obj.UserName = txtUserName.Text;
                obj.UserPassword = txtPassword.Text;
                obj.UserType = drpType.SelectedItem.ToString();

                db.tblSignups.Add(obj);

                db.SaveChanges();

                MessageBox.Show("Successful");
            }

            else
            {

                MessageBox.Show("Please fill in empty fields");

            }
            //--------------------------------------------------------------------------------------------------------------------------//




        }
        //--------------------------------------------------------------------------------------------------------------------------//
        private void btnLogin_Click(object sender, EventArgs e)
        {
            //if the login button is clicked the user will be transferred to the sign in page
            SignInForm obj = new SignInForm();
            this.Hide();
            obj.Show(); 
        }
        //--------------------------------------------------------------------------------------------------------------------------//
    }
}
