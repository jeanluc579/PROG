﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POE2_PROG
{
    public partial class FarmerProdForm : Form
    {
        public FarmerProdForm()
        {
            InitializeComponent();
        }


        PROG_POEP2Entities db = new PROG_POEP2Entities();



        public bool IsEmpty()
        {
            if(txtProdID.Text.Trim() == "" || txtProdName.Text.Trim() == "" || txtProdType.Text.Trim() == "")
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            tblFarmProd prod = new tblFarmProd();

            if(!IsEmpty() )
            {
                prod.ProdID = txtProdID.Text;   
                prod.ProdName = txtProdName.Text;
                prod.ProdType = txtProdType.Text;

                db.tblFarmProd.Add(prod);

                db.SaveChanges();

                MessageBox.Show("Successful");
            }

            else
            {
                MessageBox.Show("Please fill in empty fields");
            }
        }
    }
}
