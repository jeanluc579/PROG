﻿namespace POE2_PROG
{
    partial class EmployeeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblEmpFrmID = new System.Windows.Forms.Label();
            this.lblEmpFrmFarmerName = new System.Windows.Forms.Label();
            this.lblFarmerSurn = new System.Windows.Forms.Label();
            this.lblFarmerFarm = new System.Windows.Forms.Label();
            this.pnlEmployee = new System.Windows.Forms.Panel();
            this.txtFarmerID = new System.Windows.Forms.TextBox();
            this.txtFarmerName = new System.Windows.Forms.TextBox();
            this.txtFarmerSurn = new System.Windows.Forms.TextBox();
            this.txtFarmersFarm = new System.Windows.Forms.TextBox();
            this.btnEmpFrmAdd = new System.Windows.Forms.Button();
            this.lblEmpHomepg = new System.Windows.Forms.Label();
            this.dtaGridEmp = new System.Windows.Forms.DataGridView();
            this.btnViewList = new System.Windows.Forms.Button();
            this.btnPrdctDate = new System.Windows.Forms.Button();
            this.btnPrdctType = new System.Windows.Forms.Button();
            this.pnlEmployee.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtaGridEmp)).BeginInit();
            this.SuspendLayout();
            // 
            // lblEmpFrmID
            // 
            this.lblEmpFrmID.AutoSize = true;
            this.lblEmpFrmID.Location = new System.Drawing.Point(12, 118);
            this.lblEmpFrmID.Name = "lblEmpFrmID";
            this.lblEmpFrmID.Size = new System.Drawing.Size(56, 13);
            this.lblEmpFrmID.TabIndex = 0;
            this.lblEmpFrmID.Text = "Farmer ID:";
            // 
            // lblEmpFrmFarmerName
            // 
            this.lblEmpFrmFarmerName.AutoSize = true;
            this.lblEmpFrmFarmerName.Location = new System.Drawing.Point(12, 161);
            this.lblEmpFrmFarmerName.Name = "lblEmpFrmFarmerName";
            this.lblEmpFrmFarmerName.Size = new System.Drawing.Size(73, 13);
            this.lblEmpFrmFarmerName.TabIndex = 1;
            this.lblEmpFrmFarmerName.Text = "Farmer Name:";
            // 
            // lblFarmerSurn
            // 
            this.lblFarmerSurn.AutoSize = true;
            this.lblFarmerSurn.Location = new System.Drawing.Point(12, 207);
            this.lblFarmerSurn.Name = "lblFarmerSurn";
            this.lblFarmerSurn.Size = new System.Drawing.Size(87, 13);
            this.lblFarmerSurn.TabIndex = 2;
            this.lblFarmerSurn.Text = "Farmer Surname:";
            // 
            // lblFarmerFarm
            // 
            this.lblFarmerFarm.AutoSize = true;
            this.lblFarmerFarm.Location = new System.Drawing.Point(12, 244);
            this.lblFarmerFarm.Name = "lblFarmerFarm";
            this.lblFarmerFarm.Size = new System.Drawing.Size(70, 13);
            this.lblFarmerFarm.TabIndex = 3;
            this.lblFarmerFarm.Text = "Farmers farm:";
            // 
            // pnlEmployee
            // 
            this.pnlEmployee.BackColor = System.Drawing.Color.Red;
            this.pnlEmployee.Controls.Add(this.lblEmpHomepg);
            this.pnlEmployee.Location = new System.Drawing.Point(1, 0);
            this.pnlEmployee.Name = "pnlEmployee";
            this.pnlEmployee.Size = new System.Drawing.Size(800, 72);
            this.pnlEmployee.TabIndex = 4;
            // 
            // txtFarmerID
            // 
            this.txtFarmerID.Location = new System.Drawing.Point(171, 118);
            this.txtFarmerID.Name = "txtFarmerID";
            this.txtFarmerID.Size = new System.Drawing.Size(165, 20);
            this.txtFarmerID.TabIndex = 5;
            // 
            // txtFarmerName
            // 
            this.txtFarmerName.Location = new System.Drawing.Point(171, 161);
            this.txtFarmerName.Name = "txtFarmerName";
            this.txtFarmerName.Size = new System.Drawing.Size(165, 20);
            this.txtFarmerName.TabIndex = 6;
            // 
            // txtFarmerSurn
            // 
            this.txtFarmerSurn.Location = new System.Drawing.Point(171, 207);
            this.txtFarmerSurn.Name = "txtFarmerSurn";
            this.txtFarmerSurn.Size = new System.Drawing.Size(165, 20);
            this.txtFarmerSurn.TabIndex = 7;
            // 
            // txtFarmersFarm
            // 
            this.txtFarmersFarm.Location = new System.Drawing.Point(171, 244);
            this.txtFarmersFarm.Name = "txtFarmersFarm";
            this.txtFarmersFarm.Size = new System.Drawing.Size(165, 20);
            this.txtFarmersFarm.TabIndex = 8;
            // 
            // btnEmpFrmAdd
            // 
            this.btnEmpFrmAdd.Location = new System.Drawing.Point(195, 282);
            this.btnEmpFrmAdd.Name = "btnEmpFrmAdd";
            this.btnEmpFrmAdd.Size = new System.Drawing.Size(98, 38);
            this.btnEmpFrmAdd.TabIndex = 9;
            this.btnEmpFrmAdd.Text = "Add Farmer";
            this.btnEmpFrmAdd.UseVisualStyleBackColor = true;
            this.btnEmpFrmAdd.Click += new System.EventHandler(this.btnEmpFrmAdd_Click);
            // 
            // lblEmpHomepg
            // 
            this.lblEmpHomepg.AutoSize = true;
            this.lblEmpHomepg.BackColor = System.Drawing.Color.Yellow;
            this.lblEmpHomepg.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmpHomepg.Location = new System.Drawing.Point(240, 23);
            this.lblEmpHomepg.Name = "lblEmpHomepg";
            this.lblEmpHomepg.Size = new System.Drawing.Size(325, 31);
            this.lblEmpHomepg.TabIndex = 0;
            this.lblEmpHomepg.Text = "EMPLOYEE HOMEPAGE";
            // 
            // dtaGridEmp
            // 
            this.dtaGridEmp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtaGridEmp.Location = new System.Drawing.Point(407, 107);
            this.dtaGridEmp.Name = "dtaGridEmp";
            this.dtaGridEmp.Size = new System.Drawing.Size(381, 243);
            this.dtaGridEmp.TabIndex = 10;
            // 
            // btnViewList
            // 
            this.btnViewList.Location = new System.Drawing.Point(421, 370);
            this.btnViewList.Name = "btnViewList";
            this.btnViewList.Size = new System.Drawing.Size(106, 38);
            this.btnViewList.TabIndex = 11;
            this.btnViewList.Text = "View Farmer Items";
            this.btnViewList.UseVisualStyleBackColor = true;
            this.btnViewList.Click += new System.EventHandler(this.btnViewList_Click);
            // 
            // btnPrdctDate
            // 
            this.btnPrdctDate.Location = new System.Drawing.Point(553, 370);
            this.btnPrdctDate.Name = "btnPrdctDate";
            this.btnPrdctDate.Size = new System.Drawing.Size(98, 38);
            this.btnPrdctDate.TabIndex = 12;
            this.btnPrdctDate.Text = "Porducts by date";
            this.btnPrdctDate.UseVisualStyleBackColor = true;
            this.btnPrdctDate.Click += new System.EventHandler(this.btnPrdctDate_Click);
            // 
            // btnPrdctType
            // 
            this.btnPrdctType.Location = new System.Drawing.Point(673, 370);
            this.btnPrdctType.Name = "btnPrdctType";
            this.btnPrdctType.Size = new System.Drawing.Size(95, 38);
            this.btnPrdctType.TabIndex = 13;
            this.btnPrdctType.Text = "Product Type";
            this.btnPrdctType.UseVisualStyleBackColor = true;
            this.btnPrdctType.Click += new System.EventHandler(this.btnPrdctType_Click);
            // 
            // EmployeeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnPrdctType);
            this.Controls.Add(this.btnPrdctDate);
            this.Controls.Add(this.btnViewList);
            this.Controls.Add(this.dtaGridEmp);
            this.Controls.Add(this.btnEmpFrmAdd);
            this.Controls.Add(this.txtFarmersFarm);
            this.Controls.Add(this.txtFarmerSurn);
            this.Controls.Add(this.txtFarmerName);
            this.Controls.Add(this.txtFarmerID);
            this.Controls.Add(this.pnlEmployee);
            this.Controls.Add(this.lblFarmerFarm);
            this.Controls.Add(this.lblFarmerSurn);
            this.Controls.Add(this.lblEmpFrmFarmerName);
            this.Controls.Add(this.lblEmpFrmID);
            this.Name = "EmployeeForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "EmployeeForm";
            this.pnlEmployee.ResumeLayout(false);
            this.pnlEmployee.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtaGridEmp)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblEmpFrmID;
        private System.Windows.Forms.Label lblEmpFrmFarmerName;
        private System.Windows.Forms.Label lblFarmerSurn;
        private System.Windows.Forms.Label lblFarmerFarm;
        private System.Windows.Forms.Panel pnlEmployee;
        private System.Windows.Forms.TextBox txtFarmerID;
        private System.Windows.Forms.TextBox txtFarmerName;
        private System.Windows.Forms.TextBox txtFarmerSurn;
        private System.Windows.Forms.TextBox txtFarmersFarm;
        private System.Windows.Forms.Button btnEmpFrmAdd;
        private System.Windows.Forms.Label lblEmpHomepg;
        private System.Windows.Forms.DataGridView dtaGridEmp;
        private System.Windows.Forms.Button btnViewList;
        private System.Windows.Forms.Button btnPrdctDate;
        private System.Windows.Forms.Button btnPrdctType;
    }
}