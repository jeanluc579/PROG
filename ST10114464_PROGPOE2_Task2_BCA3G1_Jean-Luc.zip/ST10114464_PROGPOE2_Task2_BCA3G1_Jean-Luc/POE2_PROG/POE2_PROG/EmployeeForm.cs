﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POE2_PROG
{
    public partial class EmployeeForm : Form
    {
        public EmployeeForm()
        {
            InitializeComponent();
        }

        PROG_POEP2Entities db = new PROG_POEP2Entities();

        //--------------------------------------------------------------------------------------------------------------------------//


        //Make sure all the fields are entered
        public bool IsEmpty()
        {
            if(txtFarmerID.Text.Trim() == "" || txtFarmerName.Text.Trim() == "" || txtFarmerSurn.Text.Trim() == "" || txtFarmersFarm.Text.Trim() == "")
            {
                return true;
            }

            else
            {
                   
                return false;
            }
        }

        //-----------------------------------------------------------------------------------------------------------------------------//

        //-----------------------------------------------------------------------------------------------------------------------------//

        //this button adds all the farmers details to the tablke and database
        private void btnEmpFrmAdd_Click(object sender, EventArgs e)
        {
            tblFarmerDetails far = new tblFarmerDetails();

            //if else statement if the fields are filled then the info will be sent to the database else it will display an error message
            if (!IsEmpty())
            {
                far.FarmerID = txtFarmerID.Text;
                far.FarmerName = txtFarmerName.Text;
                far.FarmerSurname = txtFarmerSurn.Text;
                far.FarmersFarm = txtFarmersFarm.Text;

                db.tblFarmerDetails.Add(far);

                db.SaveChanges();

                MessageBox.Show("Successful");

            }

            else
            {
                MessageBox.Show("Please fill in empty fields");
            }
        }
        //-------------------------------------------------------------------------------------------------------------------------------//
        
        //---------------------------------------------------------------------------------------------------------------------------------//
        private void btnViewList_Click(object sender, EventArgs e)
        {
            //creating SQl connection to connect to the database to be able to view the enire table
            SqlConnection con = new SqlConnection("Data Source=PROG_POEP2;Initial Catalog=PROG_POE2;Integrated Security=True;Pooling=False");
            con.Open();
            SqlCommand cmd new SqlCOmmand("Select * from tblFarmProd", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            dtaGridEmp.DataSource = dt;
        }
        //----------------------------------------------------------------------------------------------------------------------------------//

        //----------------------------------------------------------------------------------------------------------------------------//
        private void btnPrdctDate_Click(object sender, EventArgs e)
        {

        }
        //------------------------------------------------------------------------------------------------------------------------------//

        //-----------------------------------------------------------------------------------------------------------------------------//
        private void btnPrdctType_Click(object sender, EventArgs e)
        {

        }
        //----------------------------------------------------------------------------------------------------------------------------//
    }
}
