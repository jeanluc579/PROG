﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POE2_PROG
{
    public partial class SignInForm : Form
    {
        public SignInForm()
        {
            InitializeComponent();
        }

        //--------------------------------------------------------------------------------------------------------------------------//
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        //--------------------------------------------------------------------------------------------------------------------------//
        public void clear()
        {
            txtSignInPass.Text = "";
            txtSignInUsrNm.Text = "";
        }

        //--------------------------------------------------------------------------------------------------------------------------//

        PROG_POEP2Entities db = new PROG_POEP2Entities();

        //--------------------------------------------------------------------------------------------------------------------------//
        private void btnSignInLogin_Click(object sender, EventArgs e)
        {
            //variables for the text boxes
            string username = txtSignInUsrNm.Text;
            string password = txtSignInPass.Text;


            //if else statement if the user has selected the farmer type then the user will be taken to the farmer page if the user selected
            //the employee type then the user will be taken to the employee page else a login error message will display

            var rec = db.tblSignups.Where(a=>a.UserName== username && a.UserPassword == password).FirstOrDefault();

            if (rec != null) 
            {

                //if the employee logs in, the login button will take them to the EmployeeForm page
                EmployeeForm emp = new EmployeeForm();
                this.Hide();
                emp.Show();

                MessageBox.Show("Login Success");
                clear();
            }
            //else if the login and password isn't tha of a farmer it will go to the employee page
            else if(rec ! = Employee)
            {
                FarmerProdForm fpf = new FarmerProdForm();();
                this.Hide();
                fpf.Show();
            }

            else
            {
                MessageBox.Show("Login Failed");
            }
        }
        //--------------------------------------------------------------------------------------------------------------------------//



        //--------------------------------------------------------------------------------------------------------------------------//
        private void btnSignInRegister_Click(object sender, EventArgs e)
        {
            FrmReg obj = new FrmReg();
            this.Hide();
            obj.Show();

        }
        //--------------------------------------------------------------------------------------------------------------------------//
    }
}
